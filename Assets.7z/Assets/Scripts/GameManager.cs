﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[DisallowMultipleComponent]
public class GameManager : MonoBehaviour
{
    private const int multiplierSeeds = 512;
    private const float maxSpeed = 10;
    [Header("Colors"), SerializeField]
    private Color[] colors;
    private Color trailColor;
    private float speed, currentSpeed, spawnPosition, currentCountSeedUI;
    [Header("Materials"), SerializeField, Space]
    private Material backGroundGradient;
    [SerializeField]
    private Material seedMaterial, cylinderMaterial, circleMaterial;
    [Header("Prefabs"), SerializeField, Space]
    private GameObject seed;
    [SerializeField]
    private GameObject cylinder, diedCylinder, smallDiedCylinder, sound;
    private int targetCountSeed, currentCountSeed, allQuantitySeed, multiplier;
    [Header("UI"), SerializeField, Space]
    private Image filler;
    [SerializeField]
    private Button button;
    [SerializeField]
    private RectMask2D multiplierFiller;
    [SerializeField]
    private Text counter, levelUI, multiplierText, multiplierBackGround;
    private Text mainText;
    private bool isPause;
    private void Start()
    {
        mainText = button.transform.GetComponentInChildren<Text>();
        allQuantitySeed = 0;
        multiplier = 1;
        targetCountSeed = GenerateLevel(PlayerPrefs.GetInt("Level"));
        currentSpeed = 7;
        GenerateColors();
        spawnPosition = -6;
        SpawnSeeds();
        if(PlayerPrefs.GetInt("Restart") == 0)
        {
            isPause = false;
            button.gameObject.SetActive(true);
            mainText.text = "TAP TO\nPLAY";
            currentCountSeedUI = 0;
            speed = 0;
        }
        else
        {
            PlayerPrefs.SetInt("Restart", 0);
            button.gameObject.SetActive(false);
            speed = 7;
            if (currentCountSeedUI == 0)
                filler.fillAmount = 0;
            else
                filler.fillAmount = currentCountSeedUI / targetCountSeed;
            if (currentCountSeedUI / targetCountSeed < 0.25f)
                filler.color = Color.red;
            else
            {
                if (currentCountSeedUI / targetCountSeed < 0.5f)
                    filler.color = Color.yellow;
                else
                    if (filler.color != Color.green)
                    filler.color = Color.green;
            }
        }
    }
    private void Update()
    {
        Multiplier();
        CheckPause();
        UI();
        Boost();
        SpawnCylinder();
        Move();
        Scale();
    }
    private void Multiplier()
    {
        if (multiplier < 5)
            multiplier = allQuantitySeed / multiplierSeeds + 1;
        else
            multiplier = 5;
    }
    private void CheckPause()
    {
        if (Input.GetKeyDown(KeyCode.R))
            Reset();
        if (Input.GetKeyDown(KeyCode.Escape))
            if (speed != 0)
                Pause();
            else
                Resume();
    }
    private void UI()
    {
        if (multiplier < 5)
            multiplierFiller.padding = new Vector4(0, 0, 0, 36 * (1 - ((float)allQuantitySeed % multiplierSeeds) / multiplierSeeds));
        else
            multiplierFiller.padding = new Vector4(0, 0, 0, 0);
        multiplierText.text = "x" + System.Convert.ToString(multiplier);
        multiplierBackGround.text = "x" + System.Convert.ToString(multiplier);
        levelUI.text = System.Convert.ToString(PlayerPrefs.GetInt("Level") + 1);
        if (currentCountSeedUI == 0)
            filler.fillAmount = 0;
        else
            filler.fillAmount = currentCountSeedUI / targetCountSeed;
        if (currentCountSeedUI / targetCountSeed < 0.25f)
            filler.color = Color.red;
        else
        {
            if (currentCountSeedUI / targetCountSeed < 0.5f && filler.color != Color.yellow)
                filler.color += (Color.yellow - Color.red) * Time.deltaTime;
            else
                if(filler.color != Color.green)
                filler.color += (Color.green - Color.yellow) * Time.deltaTime;
        }
        if (currentCountSeedUI < currentCountSeed)
            currentCountSeedUI += Time.deltaTime * 96 * multiplier;
        else
            currentCountSeedUI = currentCountSeed;
        counter.text = System.Convert.ToString(System.Math.Truncate(currentCountSeedUI));
    }
    public void UIButton()
    {
        if (mainText.text == "TAP TO\nRESUME" || mainText.text == "TAP TO\nPLAY")
            Resume();
        if (mainText.text == "TAP TO\nRESTART")
            Restart();
    }
    private void Boost()
    {
        if (!isPause)
        {
            if (speed < maxSpeed)
                speed += 0.02f * Time.deltaTime;
            else
                speed = 10;
        }
    }
    private void SpawnSeeds()
    {
        float radius = 1.25f;
        int count = Random.Range(2, 5);
        for (int i = 0; i < count; i++)
        {
            for (float j = 0; j < 360f * Mathf.Deg2Rad; j += 22.5f * Mathf.Deg2Rad)
            {
                GameObject gb = Instantiate(seed,
                    new Vector3(radius * Mathf.Sin(j), spawnPosition + (i - 2) * 0.5f, radius * Mathf.Cos(j)),
                    Quaternion.Euler(0, j, 0));
                gb.transform.GetChild(0).transform.rotation = Quaternion.Euler(-90, 0, j * Mathf.Rad2Deg);
                SetTrail(gb);
                StartCoroutine(WaitAndDie(gb));
            }
            StartCoroutine(WaitAndDie(Instantiate(sound,
                new Vector3(0, spawnPosition + (i - 2) * 0.5f, 0),
                Quaternion.identity)));
        }
    }
    private void SpawnCylinder()
    {
        if (transform.position.y > spawnPosition - 16)
        {
            if(transform.position.y > 6)
            {
                int p = Random.Range(0, 2);
                if (p == 0)
                {
                    if (Random.Range(0, 2) == 0)
                        SpawnSeeds();
                    else
                        SpawnDiedCylinder();
                }
                else
                {
                    if (Random.Range(0, 3) == 0)
                        SpawnSmallDiedCylinder();
                }
            }
            StartCoroutine(WaitAndDie(Instantiate(cylinder,
                new Vector3(0, spawnPosition, 0), 
                Quaternion.Euler(-90, 0, 0))));
            spawnPosition += 2;
        }
    }
    private void SpawnSmallDiedCylinder()
    {
        StartCoroutine(WaitAndDie(Instantiate(smallDiedCylinder,
            new Vector3(0, spawnPosition, 0), Quaternion.Euler(-90, 0, 0))));
    }
    private void SpawnDiedCylinder()
    {
        StartCoroutine(WaitAndDie(Instantiate(diedCylinder,
            new Vector3(0, spawnPosition, 0), Quaternion.Euler(-90, 0, 0))));
    }
    private void SetTrail(GameObject gameObject)
    {
        var trails = gameObject.transform.GetChild(0).GetComponent<ParticleSystem>().trails;
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new GradientColorKey[] { new GradientColorKey(trailColor, 0.0f), new GradientColorKey(new Color(1, 1, 1, 0), 1f) },
            new GradientAlphaKey[] { new GradientAlphaKey(1, 0), new GradientAlphaKey(0, 0.8f) }
            );
        trails.colorOverTrail = gradient;
    }
    private void CheckCompliteLevel()
    {
        if (currentCountSeed >= targetCountSeed && targetCountSeed != 0)
        {
            PlayerPrefs.SetInt("Level", PlayerPrefs.GetInt("Level") + 1);
            targetCountSeed = GenerateLevel(PlayerPrefs.GetInt("Level"));
            currentCountSeed = 0;
        }
    }
    private int GenerateLevel(int level)
    {
        int count = 0;
        count = 178 + level * 163 - (level % 10) + (level * 12) % 100;
        count -= count % 16;
        return count;
    }
    private void GenerateColors()
    {
        int up = Random.Range(0, colors.Length), down = 0, cylinder = 0;
        while ((down = Random.Range(0, colors.Length)) == up) ;
        while ((cylinder = Random.Range(0, colors.Length)) == up || (cylinder = Random.Range(0, colors.Length)) == down) ;
        backGroundGradient.SetColor("Color_E185B6D", colors[down]);
        backGroundGradient.SetColor("Color_548C3A17", colors[up]);
        circleMaterial.SetColor("Color_AA046982", colors[down]);
        trailColor = colors[up];
        seedMaterial.SetColor("Color_AA046982", colors[up]);
        cylinderMaterial.SetColor("Color_AA046982", colors[cylinder]);
        backGroundGradient.SetFloat("Vector1_CB63446F", 1);
    }
    private void Move()
    {
        transform.position += new Vector3(0, 1, 0) * Time.deltaTime * speed;
        Camera.main.transform.position = transform.position + new Vector3(0, -4, -10);
    }
    private void Scale()
    {
        if(!isPause && speed > 6)
        {
            if (Input.GetMouseButton(0))
                if (transform.localScale.x > 66f)
                    transform.localScale -= new Vector3(300, 300, 0) * Time.deltaTime;
                else
                    transform.localScale = new Vector3(66f, 66f, 100);
            else
                if (transform.localScale.x < 100f)
                transform.localScale += new Vector3(300, 300, 0) * Time.deltaTime;
            else
                transform.localScale = new Vector3(100f, 100f, 100);
        }
    }
    private void Impulse(GameObject obj)
    {
        Vector3 impulse = Vector3.zero;
        impulse.x = 12 * Mathf.Sin(obj.transform.rotation.eulerAngles.y);
        impulse.y = 4;
        impulse.z = 12 * Mathf.Cos(obj.transform.rotation.eulerAngles.y);
        obj.GetComponent<Rigidbody>().AddForce(impulse * 4f, ForceMode.Impulse);
        obj.GetComponent<Rigidbody>().useGravity = true;
    }
    private void Pause()
    {
        button.gameObject.SetActive(true);
        mainText.text = "TAP TO\nRESUME";
        currentSpeed = speed;
        speed = 0;
        isPause = true;
    }
    private void Resume()
    {
        button.gameObject.SetActive(false);
        speed = currentSpeed;
        isPause = false;
    }
    private void Restart()
    {
        PlayerPrefs.SetInt("Restart", 1);
        SceneManager.LoadScene("Game");
    }
    private void Reset()
    {
        PlayerPrefs.SetInt("Level", 0);
        SceneManager.LoadScene("Game");
    }
    private void Died()
    {
        button.gameObject.SetActive(true);
        mainText.text = "RESTART";
        StopAllCoroutines();
        speed = 0;
    }
    private void OnTriggerEnter(Collider other)
    {
        if((other.CompareTag("DiedCylinder") && !Input.GetMouseButton(0)) || 
            (other.CompareTag("SmallDiedCylinder") && Input.GetMouseButton(0)))
        {
            Died();
            mainText.text = "TAP TO\nRESTART";
        }
        if(other.CompareTag("Seed") && Input.GetMouseButton(0))
        {
            if(Random.Range(0, 4) == 0)
                other.transform.GetChild(0).GetComponent<ParticleSystem>().Play();
            CheckCompliteLevel();
            Impulse(other.gameObject);
        }
        if (other.CompareTag("Sound") && Input.GetMouseButton(0))
        {
            other.GetComponent<BoxCollider>().enabled = false;
            other.GetComponent<AudioSource>().pitch -= Random.Range(-0.1f, 0.1f);
            other.GetComponent<AudioSource>().Play();
            currentCountSeed += 16 * multiplier;
            allQuantitySeed += 16;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if(other.CompareTag("Sound") && !Input.GetMouseButton(0))
        {
            multiplier = 1;
            allQuantitySeed = 0;
        }
    }
    IEnumerator WaitAndDie(GameObject obj)
    {
        while(transform.position.y - obj.transform.position.y <= 10f)
            yield return new WaitForSeconds(1);
        Destroy(obj);
    }
}
